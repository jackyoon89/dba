-- parameter #1: schema (case sensitive)
-- parameter #2: object_name (case sensitive)

SET LIN 80
PRO
PRO /*************************************************************************************
PRO
DESC &&1..&&2.
PRO *************************************************************************************/
@@set_session_environment.sql
